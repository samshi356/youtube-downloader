from flask import Flask, request, jsonify, send_from_directory, render_template
from pytube import YouTube
import os

app = Flask(__name__)
DOWNLOAD_FOLDER = "downloads"
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/download", methods=["POST"])
def download_video():
    data = request.json
    video_url = data.get("video_url")
    quality = data.get("quality", "high")

    try:
        yt = YouTube(video_url)
        if quality == "low":
            stream = yt.streams.filter(progressive=True, file_extension='mp4').order_by("resolution").first()
        else:
            stream = yt.streams.filter(progressive=True, file_extension='mp4').order_by("resolution").last()

        filename = yt.title.replace(" ", "_").replace("/", "_") + ".mp4"
        stream.download(output_path=DOWNLOAD_FOLDER, filename=filename)
        return jsonify({"status": "success", "file_url": f"/file/{filename}"})

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route("/file/<filename>")
def serve_file(filename):
    return send_from_directory(DOWNLOAD_FOLDER, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
